echo "Enter the string: "
read z
revstr=""
for (( i=0; i<${#z}; i++ ))
do
        revstr=${z:$i:1}$revstr
done

if [ "$z" = "$revstr" ]; then
        echo "It is a palindrome."
else
        echo "It is not a palindrome."
fi

