#!/bin/bash  

read -p "Enter directory name : " dir

if [ -e $dir ]
then echo "directory already exists"
else 
echo "directory does not exist"
mkdir $dir
fi
