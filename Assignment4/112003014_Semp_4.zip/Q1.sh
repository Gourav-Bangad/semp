#!/bin/bash  

File='readFile.txt'

if test -f "$File";then
echo "$File exist"
echo "hello world" >> $File

else
echo "$File does not exist"
echo "hello world" > $File

fi


